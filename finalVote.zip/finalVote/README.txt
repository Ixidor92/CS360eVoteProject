Contents of file:

-.settings folder
-bin folder: location for class files
-dump.sql: single file executable for database import
-dump zip file: zipped dump folder for database import
-mysql-connector-java-5.1.40: needed for mysql to function with code
-src folder: location of source files
-.classpath
-.project
-README.txt: this instruction file

Instructions to run:
-import "finalVote" as a new project in a java IDE, preferably eclipse.
-ensure that the database is set up properly (instructions further down)
-Check for two possible errors:
	check the libraries of the project in eclipse (or your preferred IDE).
	Under "referenced libraries" should be a referenced .jar file:
	mysql-connector-java-5.1.40-bin.jar
	If this reference is not present, add it to the build path
	in eclipse, this is done by right-clicking the libraries, selecting "configure build path" then clicking "add external jar"
	The .jar file that needs to be referenced is in mysql-connector-java-5 folder
	ensure this is referenced
	
	If running on an older version of java (this was confirmed to occur with Java 1-6) several lines of
	code will be in red.  These are variables that must be declared final for the code to compile.
	Eclipse offers the quick fix to automatically make these variables final.
	Changing them to final upon initial testing does not appear to change the functionality of the system.
-The main method for this system is located in "Election.java", run the system from this file as a java application

Instructions for Database:
-These instructions are for the implementation of MySql, and assumes a basic knowledge of the program.
-Open your local instance of MySql
-access your localhost server, port 3306
-once you are in your localhost server, create a new schema/database titled "evote"
-within mySql, select the "server" drop-down menu, and select "import"
-You will have the option of importing from a dump folder, or a single executable.
-both of these are included in the file, start with the single executable.
-Select whichever import option you would prefer, and browse the system for the folder/file
-both files are located in the top-level directory of the system
-Within the import wizard is an option for the destination schema.  Make sure that "evote" is the destination.
-THE CODE WILL NOT WORK OUTSIDE OF "evote".  Once this is done, start the import.
-If you wish, open the evote schema and check the tables.
-There should be tables for nominees, registered voters, and committee member logins/passwords


Instructions for use of system:
-Upon startup, the system will immediately ask for a system password.  Use the password for your localhost database
-Once the system is running, it will open an initial window allowing for a committee member to login,
or for a user to vote if it is enabled.  By default, the system opens with voting being disabled.
-Enter a valid login/password combination and hit "login" to be brought to committee options.
-The committee options are as follows:
	-Start Election: enables use of the vote function
	-Halt Election: disables use of the vote function
	-view results: displays the current standings of the nominees. This function is unavailable while voting is enabled.
	-Exit: exits back to the main menu.  If voting is disabled, a warning message will appear.
	-End Election: Exits the entire system.  This will end the election permanently.
		this function is unavailable while voting is enabled, and will display a warning when accessed regardless.

-Once voting has been enabled, and the committee options have been exited, the user has the option to vote.
-Clicking this button will immediately prompt for a voterID
-The system will print an error message if an invalid ID is given
-If a valid ID is given, but the user has already voted in this election, then the system will print a different message
-If the user is valid and has not voted, only then does the next window open up.
-There are a number of circle boxes here, each mapping to a candidate.
-Selecting the candidate of your choice and hitting "vote" will prompt for a confirmation of their choice
-At any point, the voter can hit "cancel" and be taken back to the main screen.

That is all the system functionality
The system comes pre-shipped with all registered voters, nominees, and committee members
These will need to be added to the database from the back end if they need to be changed