package eVoting;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class ElectorateCommittee 
{
	private SqlConnector connection;
	
	public ElectorateCommittee (SqlConnector connector)
	{
		this.connection = connector;
	}
	//returns the userName and password of a committee member
	public void viewMember (int memberID) throws SQLException
	{
		ResultSet member = connection.getData("SELECT * FROM members WHERE id = " + Integer.toString(memberID));
		if (!member.first())
		{
			System.out.println("The is no such user identification");
		}
		else
		{
			System.out.println(member.getString("username"));
			System.out.println(member.getString("password"));
		}
	}
	
	//lists the votes of a single given nominee
	public void viewNomineeVotes (int nomineeID) throws SQLException
	{
		ResultSet nominee = connection.getData("SELECT * FROM nominees WHERE ID = " + Integer.toString(nomineeID));
		if (!nominee.first())
		{
			System.out.println("There is no such nominee identification");
		}
		else
		{
			System.out.println(nominee.getString("Name"));
			System.out.println(nominee.getString("Party"));
			System.out.println(nominee.getString("votes"));
		}
	}
	
	//returns a string containing the results of the election
	//This includes the votes each candidate has, as well as the total number of votes cast
	public String viewResults() throws SQLException
	{
		int totalVotes = 0;
		String resultString = "";
		ResultSet results = connection.getData("SELECT * FROM evote.nominees");
		while(results.next())
		{
			resultString += "\n";
			resultString += ("Candidate: " + results.getString("Name") +
						" has " + results.getString("votes") + " votes currently.");
			totalVotes += results.getInt("votes");
		}
		resultString += "\n" + "Total number of votes: " + Integer.toString(totalVotes);
		return resultString;
	}
	
	public boolean login(Scanner input) throws SQLException
	{
		boolean successful = false;
		System.out.println("Please enter your username: ");	//query the user for their username
		String username = input.next();
		
		
		String query = "SELECT * FROM evote.members WHERE members.username = \"" + username + "\"";	//look for members with the given username 
		ResultSet member = connection.getData(query);
		if(!member.first())
		{
			System.out.println("No member found with the given username");
		}
		else
		{
			//check for the user AND password
			boolean found = false;
			int count = 0;
			while(!found && count < 3)
			{
				//prompt the user for either their password, or 0 to return to selection screen
				System.out.println("Please enter your password: ");	//query the user for their password
				String pass = input.next();
				
				query = "SELECT * FROM evote.members WHERE members.username = \"" + username + "\" AND password = \"" + pass + "\"";
				member = connection.getData(query);
				if(!member.first())
				{
					System.out.println("The password that you entered was incorrect.");
					count++;
				}
				else
				{
					System.out.println("Logging in...");
					found = true;
					successful = true;
				}
			}
			if(count == 3)
			{//if there have been three attempts to enter the password
				System.out.println("You have failed to enter your login information correctly.  Please reattempt.");
			}
			
		}
		return successful;
	}
	
	//version of the login method that takes two string arguments (the username and password).  Meant for use with JFrame arguments
	//returns an integer noting any issues
	//returning 0 means nothing went wrong
	//returning 1 means the user was found, but the password was incorrect
	//returning -1 means that no user was found
	public int login(String username, String password) throws SQLException
	{
		int result = 0;
		
		String query = "SELECT * FROM members WHERE username = \"" + username + "\"";	//look for members with the given username 
		ResultSet member = connection.getData(query);
		if(!member.first())
		{
			result = -1;
		}
		else
		{
			query = "SELECT * FROM members WHERE username = \"" + username + "\" AND password = \"" + password + "\"";
			member = connection.getData(query);
			if(!member.first())
			{
				result = 1;
			}
		}
		
		return result;
	}
	
	//gets the percentage participation from this election
	public double getParticipation() throws SQLException
	{
		double result = 0.0;
		double registered = 0.0;
		double voted = 0.0;
		
		String query = "SELECT * FROM registeredVoters ";
		ResultSet totals = connection.getData(query);
		
		//step through the entire ResultSet, and tally how many total voters there are, as well as how many actually voted
		totals.beforeFirst();
		while(totals.next())
		{
			registered += 1;	//since there is another row, there is another registered voter
			if(totals.getInt("hasVoted") == 1)
			{//if the individual above has voted, note that they have done so
				voted += 1;
			}
		}
		
		//calculate the percentage of how many have voted in this election
		result = voted/registered;
		result = result * 100;	//turn it into a more recognizable percentage value
		
		return result;
	}
	
	//This method displays the results of the election using a different method of counting
	//this method is less effective, but also more difficult to falseify.
	public String recount() throws SQLException
	{
		String results;
		
		String query = "SELECT * from evote.recountdata";
		ResultSet recounter = connection.getData(query);
		
		if(!recounter.first())
		{
			results = "";	//if there are no results in the table, then there are no values to show
		}
		else
		{
			//pull a result set of the candidates
			query = "SELECT * FROM evote.nominees";
			ResultSet nominees = connection.getData(query); 
			nominees.last();
			
			int candidateNumbers = nominees.getRow();	//find how many candidates there are
			int[] candidates = new int[candidateNumbers];	//holds the number of votes each candidate has
			int currentCandidate;							//which candidate is has been voted for in the current row
			recounter.beforeFirst();						//moves the counter for the ResultSet before starting the count
			
			//go through each row in the table
			//each row represents a single ballot for a candidate, and will be counted manually into the array of candidates
			while(recounter.next())
			{
				currentCandidate = (recounter.getInt(2)-1);		//second column holds the ID of the candidate, -1 takes into account IDs for candidates start at 1 instead of 0
				candidates[currentCandidate] += 1;
			}
			
			results = "";
			nominees.beforeFirst();
			currentCandidate = 0;
			
			//create the string to display results
			while(nominees.next())
			{
				results += "\n" +
						"Candidate " + nominees.getString(2) +
						" has " + candidates[currentCandidate] +
						" votes.";
				currentCandidate += 1;
			}
			recounter.last();
			int totalVotes = recounter.getRow();
			results += "\n" + "Total votes: " + Integer.toString(totalVotes);
		}
		
		return results;
	}
	
	
}